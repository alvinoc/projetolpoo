package interfacegrafica;
import br.com.poli.Partida;
import br.com.poli.DificuldadePartida;
import br.com.poli.Jogador;
import br.com.poli.Tabuleiro;
import br.com.poli.exceptions.MovimentoIncorretoException;
import br.com.poli.exceptions.MovimentoInvalidoException;
import br.com.poli.exceptions.TabuleiroSemSolucaoException;
import br.com.poli.interfaces.CalculaScore;
import br.com.poli.CalculaScoreComIdade;
import br.com.poli.CalculaScoreSemIdade;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Interface {


	public static void main(String[] args) throws MovimentoInvalidoException, MovimentoIncorretoException, TabuleiroSemSolucaoException  {
		Jogador jogador = new Jogador(12,"asdads", 123);
		int[][] gabarito = {
				{8,3,2,4,7,5,6,9,1},
				{9,5,6,3,8,1,4,7,2},
				{7,4,1,6,2,9,8,3,5},
				{6,9,8,7,5,3,2,1,4},
				{3,7,5,2,1,4,9,8,6},
				{1,2,4,9,6,8,3,5,7},
				{4,1,3,5,9,2,7,6,8},
				{5,6,9,8,4,7,1,2,3},
				{2,8,7,1,3,6,5,4,9},};
		int[][]	grid = {
				{8,3,0,0,0,5,6,9,0},
				{0,0,6,0,8,0,0,0,2},
				{0,0,0,6,0,0,0,0,5},
				{6,0,0,0,0,3,0,0,0},
				{3,0,5,0,0,0,9,0,6},
				{0,0,0,9,0,0,0,0,7},
				{4,0,0,0,0,2,0,0,0},
				{5,0,0,0,4,0,1,0,0},
				{0,8,7,1,0,0,0,4,9}};

		Date data = new Date();
		Tabuleiro tabuleiro = new Tabuleiro(gabarito, grid);
		Partida partida = new Partida(jogador, tabuleiro, 1, false, 0, data);
		DificuldadePartida facil =   DificuldadePartida.FACIL;
		CalculaScore calcularScore = new CalculaScoreComIdade();

		Scanner entrada = new Scanner(System.in);
		Scanner nome = new Scanner(System.in);
		Scanner idade = new Scanner(System.in);
		Scanner dificuldade = new Scanner(System.in);
		Scanner iniciar = new Scanner(System.in);
		Scanner posX = new Scanner(System.in);
		Scanner posY = new Scanner(System.in);
		Scanner svalor = new Scanner(System.in);
		Scanner desistir = new Scanner(System.in);
		double desi;
		int opcao;
		int x, y, valor;
		



		System.out.println("\n\n                               ### Sudoku ###              ");
		System.out.println("\n                  ===========================================");
		System.out.println("                  |     1 - Digite seu nome                   |");
		System.out.println("                  |     2 - Digite sua idade                  |");
		System.out.println("                  |     3 - Dificuldade: Facil, Medio, Dificil|");
		System.out.println("                  |     4 - Iniciar partida  [1]Sim [2]Nao    |");
		System.out.println("                  ===========================================\n");
		nome.next();
		idade.next();
		dificuldade.next();
		opcao = iniciar.nextInt();
		if(opcao ==1) {

			partida.iniciarPartida();
			System.out.println("Para desistir digite 1.5");
			desi = desistir.nextDouble();
			if(desi == 1.5) {
				partida.resolvedor(0, 0);
				System.out.println("jogo finalizado");
				System.out.printf("Jogador: %s,idade: %s, dificuldade: %s", nome,idade,dificuldade);
				calcularScore.calcula(partida);
				
				System.exit(0);
			}
			
			try {
				System.out.println("tempo: "+data.getMinutes());
				System.out.println("Digite as posicoes x, y e o valor");


				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("tempo: "+data.getMinutes());
				System.out.println("Digite as posicoes x, y e o valor");


				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}


			try {
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			try{
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			try{
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			try{
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");
				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
				System.out.println("tempo: "+data.getMinutes());
			}
			try{
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}

			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}

			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {

				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");

				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}

			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}

			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}

			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}

			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}

			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());

				System.out.println("tempo: "+data.getMinutes());
			}
			try {
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
			}catch(MovimentoIncorretoException | MovimentoInvalidoException e) {
				System.out.println("Jogada nao possivel");
				System.out.println("Digite as posicoes x, y e o valor");

				x = posX.nextInt();
				y = posY.nextInt();
				valor = svalor.nextInt();
				partida.executarMovimento(x, y, valor);
				System.out.println("quantidade de erros: "+partida.getQntdeErros());
			}
			if(grid==gabarito) {
				
			System.out.println("Jogo finalizado");
			System.out.println("Jogador	: "+nome+"idade: " +idade+"dificuldade" +dificuldade);
			calcularScore.calcula(partida);
			System.exit(0);
			}














		}else {
			System.out.println("Jogo finalizado");
			System.exit(0);
		}

	}
}

