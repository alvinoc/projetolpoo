package br.com.poli;

public class Jogador extends Pessoa {
	//atributos
	private int scoreRecorde;
	
	//get e set
	
	
	public int getScoreRecorde() {
		return scoreRecorde;
	}
	public void setScoreRecorde(int scoreRecorde) {
		this.scoreRecorde = scoreRecorde;
	}
	
	//construtor
	public Jogador(int idade, String nome, int scoreRecorde) {
		super(idade, nome);
		this.scoreRecorde = scoreRecorde;
	}
	
	
	
	

	
	}
	

