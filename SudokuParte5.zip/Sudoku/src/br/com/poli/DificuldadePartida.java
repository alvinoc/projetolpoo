package br.com.poli;

public enum DificuldadePartida {
	FACIL(1,1), NORMAL(2,2), DIFICIL(3,3);
	
	private int valor;
	private int qntdeMaxErros;
	
	//get e set
	public int getValor() {
		return valor;
	}
	public void setValor(int valor) {
		this.valor = valor;
	}
	public int getQntdeMaxErros() {
		return qntdeMaxErros;
	}
	public void setQntdeMaxErros(int qntdeMaxErros) {
		this.qntdeMaxErros = qntdeMaxErros;
	}
	
	//construtor
	private DificuldadePartida(int valor, int qntdeMaxErros){
		this.valor = valor;
		this.qntdeMaxErros = qntdeMaxErros;		
	}
	 }

