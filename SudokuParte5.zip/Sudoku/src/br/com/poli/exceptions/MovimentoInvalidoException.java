package br.com.poli.exceptions;

public class MovimentoInvalidoException extends Exception {
	private String msg;

	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public MovimentoInvalidoException(String msg){
		super(msg);
		this.setMsg(msg);
	}

}
