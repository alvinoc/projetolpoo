package br.com.poli.exceptions;

public class MovimentoIncorretoException extends Exception {
	
	private String msg;
	
		public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
	    public MovimentoIncorretoException(String msg){
		      super(msg);
		      this.setMsg(msg);
		    }

	
}
