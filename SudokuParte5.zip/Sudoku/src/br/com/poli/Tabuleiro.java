package br.com.poli;

import java.util.Arrays;
import java.util.Random;

import br.com.poli.exceptions.MovimentoIncorretoException;
import br.com.poli.exceptions.MovimentoInvalidoException;
import br.com.poli.interfaces.ResolvedorSudoku;
import br.com.poli.exceptions.TabuleiroSemSolucaoException;

public class Tabuleiro implements ResolvedorSudoku {
	// atributos
	private int[][] gabarito ;
	private  int[][] grid;


	// get e set
	public int[][] getGabarito(){
		return gabarito;
	}
	public void setGabarito(int[][] gabarito){
		this.gabarito = gabarito;
	}
	public int[][] getGrid(){
		return grid;
	}
	public void setGrid(int [][] grid){
		this.grid = grid;
	}

	//construtor
	public Tabuleiro(int[][] gabarito, int[][] grid){
		this.gabarito = gabarito;
		this.grid = grid;
	}

	//metodos

	public  boolean executarMovimento(int posX, int posY, int valor) throws MovimentoInvalidoException, MovimentoIncorretoException  {

		if(posX < 0 || posY < 0){
			System.out.println("As posicoes devem ser numeros positivos");
			return false;
		}else{
			if(valor < 1 || valor > 9){
				throw new MovimentoInvalidoException("Movimento Invalido!!");
			}
		}

		if(posX > grid.length || posY > grid.length){
			throw new   MovimentoInvalidoException("MovimentoInvalido");

		}else{ 



			if (valor !=gabarito[posX][posY] ){
				throw new MovimentoIncorretoException("MovimentoIncorreto");

			}
		}
		
		grid[posX][posY] = valor;
		arrayToString(grid);
		
		return true;




	}

	public   boolean isTabuleiroPreenchido(int lin, int col, int n){
		int l, c, lr, cr;

		if (grid[lin][col] == n) return true;
		if (grid[lin][col] != 0) return false;
		for (c = 0; c < 9; c++)
			if (grid[lin][c] == n) return false;
		for (l = 0; l < 9; l++)
			if (grid[l][col] == n) return false;
		lr = lin / 3;
		cr = col / 3;
		for (l = lr * 3; l < (lr + 1) * 3; l++)
			for (c = cr * 3; c < (cr + 1) * 3; c++)
				if (grid[l][c] == n) return false;

		return true;

	}

	public void imprime() {


		int l, c;


		for (l = 0; l < 9; l++) {
			for (c = 0; c < 9; c++) {
				System.out.printf(" %d", grid[l][c]);
				if (c % 3 == 2)  System.out.printf("  ");
			}
			System.out.printf("\n");
			if (l % 3 == 2)  System.out.printf("\n");
		}

	}

	//metodo criado para printar o o tabuleiro no console, ja que System.out.println() nao recebe int[][] como parametro
	public static String arrayToString(int[][] grid) {

	    String aString;     
	    aString = "";
	    int coluna;
	    int linha;

	    for (linha = 0; linha < grid.length; linha++) {
	        for (coluna = 0; coluna < grid[0].length; coluna++ ) {
	        aString = aString + " " + grid[linha][coluna];
	        }
	    aString = aString + "\n";
	    }
	    System.out.println(aString);
	    return aString;
	}







	public  void geraTabuleiro(DificuldadePartida valor){

		int dificil = 0 , facil = 0, normal = 0;
		Random rand = new Random();




		if(valor == DificuldadePartida.DIFICIL){
			imprime();
			while(dificil<77){
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				dificil++;

			}


		} else if(valor == DificuldadePartida.NORMAL){
			imprime();
			while(normal<60){
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;

				normal++;

			}

		} else {// Se nao for dificil nem normal, eh facil.
			imprime();
			while(facil<40){
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;
				grid[rand.nextInt(8)][rand.nextInt(8)] = 0;

				facil++;

			}
		}
	}
	@Override
	public void resolvedor(int lin, int col) throws TabuleiroSemSolucaoException {
		int n, t;
		try{
			if (lin == 9)
				imprime();
			else
				for (n = 1; n <= 9; n++)
					if (isTabuleiroPreenchido(lin, col, n) ==true) {
						t = grid[lin][col];
						grid[lin][col] = n;
						if (col == 8)
							resolvedor(lin + 1, 0);
						else
							resolvedor(lin, col + 1);
						grid[lin][col] = t;
					}
		}catch(Exception TabuleiroSemSolucaoException){
			throw TabuleiroSemSolucaoException;
		}
	}

}


