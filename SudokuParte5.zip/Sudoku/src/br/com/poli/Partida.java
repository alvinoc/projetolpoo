package br.com.poli;
import java.util.Date;

import br.com.poli.exceptions.MovimentoIncorretoException;
import br.com.poli.exceptions.MovimentoInvalidoException;
import br.com.poli.interfaces.ResolvedorSudoku;
import br.com.poli.exceptions.TabuleiroSemSolucaoException;

public class Partida implements ResolvedorSudoku {
	private Jogador jogador;
	private Tabuleiro tabuleiro;
	private int qntdeErros;
	private boolean venceu;
	private int score;
	private Date tempo;
	private DificuldadePartida dificuldade;

	//get e set
	public Jogador getJogador() {
		return jogador;
	}

	public void setJogador(Jogador jogador) {
		this.jogador = jogador;
	}

	public Tabuleiro getTabuleiro() {
		return tabuleiro;
	}

	public void setTabuleiro(Tabuleiro tabuleiro) {
		this.tabuleiro = tabuleiro;
	}

	public int getQntdeErros() {
		return qntdeErros;
	}

	public void setQntdeErros(int qntdeErros) {
		this.qntdeErros = qntdeErros;
	}

	public boolean getVenceu() {
		return venceu;
	}

	public void setVenceu(boolean venceu) {
		this.venceu = venceu;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Date getData() {
		return tempo;
	}

	public void setData(Date tempo) {
		this.tempo = tempo;
	}

	public DificuldadePartida getDificuldade() {
		return dificuldade;
	}

	public void setDificuldade(DificuldadePartida dificuldade) {
		this.dificuldade = dificuldade;
	}

	//construtor
	public Partida(Jogador jogador,Tabuleiro tabuleiro, int qntdeErros, boolean venceu, int score, Date tempo){
		this.jogador = jogador;
		this.tabuleiro = tabuleiro;
		this.qntdeErros = qntdeErros;
		this.venceu = venceu;
		this.score = score;
		this.tempo = tempo;
	}

	//metodos


	public void executarMovimento(int x, int y,int valor) throws MovimentoInvalidoException,  MovimentoIncorretoException{

		tabuleiro.executarMovimento(x, y, valor);
		try {
			if(tabuleiro.executarMovimento(x, y, valor)){
				tabuleiro.isTabuleiroPreenchido(x, y, valor);
				venceu = true;
			}
		} catch(Exception MovimentoIncorretoException ){
			qntdeErros++;
			throw MovimentoIncorretoException;
		}




	}
	public boolean isFimDeJogo(){
		if(qntdeErros == DificuldadePartida.FACIL.getQntdeMaxErros()){
			return true;

		}else{
			return false;
		}
	}

	public void iniciarPartida(){
		qntdeErros = 0;
		tempo = new Date();
		venceu = false;
		tabuleiro.imprime();
		
	}



	public void resolvedor(int lin, int col) throws TabuleiroSemSolucaoException{
		int n, t;
		try{
			if (lin == 9)
				tabuleiro.imprime();
			else
				for (n = 1; n <= 9; n++)
					if (tabuleiro.isTabuleiroPreenchido(lin, col, n) ==true) {
						t = tabuleiro.getGrid()[lin][col];
						tabuleiro.getGrid()[lin][col] = n;
						if (col == 8)
							resolvedor(lin + 1, 0);
						else
							resolvedor(lin, col + 1);
						tabuleiro.getGrid()[lin][col] = t;
					}
		}catch(Exception TabuleiroSemSolucaoException){
			throw TabuleiroSemSolucaoException;

		}
	}

}
