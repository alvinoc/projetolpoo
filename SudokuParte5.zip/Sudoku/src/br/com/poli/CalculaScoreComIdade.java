package br.com.poli;

import br.com.poli.interfaces.CalculaScore;
import java.util.Date;

public class CalculaScoreComIdade implements CalculaScore {

	
	public void calcula(Partida partida) {
		DificuldadePartida facil = DificuldadePartida.FACIL;
		DificuldadePartida normal = DificuldadePartida.NORMAL;
		DificuldadePartida dificil = DificuldadePartida.DIFICIL;
		Date tempoDecorrido = new Date();
		int idade = 0;
		if(partida.getDificuldade() == facil && idade <= 12 ){
			 partida.setScore(partida.getScore()  - partida.getQntdeErros() - tempoDecorrido.getMinutes());
			 System.out.println(partida.getScore());
			 
		}
		if(partida.getDificuldade() == facil && idade > 12 ){
			partida.setScore(partida.getScore()  - partida.getQntdeErros() - idade - tempoDecorrido.getMinutes()); 
			System.out.println(partida.getScore());
		}
		if(partida.getDificuldade() == normal && idade <= 12){
			partida.setScore(partida.getScore() - partida.getQntdeErros()*2 - idade - tempoDecorrido.getMinutes());
			System.out.println(partida.getScore());
		}
		if(partida.getDificuldade() == normal && idade > 12){
			partida.setScore(partida.getScore() - partida.getQntdeErros()*2 - idade*2 - tempoDecorrido.getMinutes());
			System.out.println(partida.getScore());
		}
		if(partida.getDificuldade() == dificil && idade <= 12){
			partida.setScore(partida.getScore() - partida.getQntdeErros()*3 - idade - tempoDecorrido.getMinutes());
			System.out.println(partida.getScore());
		}
		if(partida.getDificuldade() == dificil && idade > 12){
			partida.setScore(partida.getScore() - partida.getQntdeErros()*3 - idade*3 - tempoDecorrido.getMinutes());
			System.out.println(partida.getScore());
		}
	}
	
}
