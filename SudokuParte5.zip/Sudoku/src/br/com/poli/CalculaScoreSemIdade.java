package br.com.poli;

import br.com.poli.interfaces.CalculaScore;
import java.util.Date;

public class CalculaScoreSemIdade implements CalculaScore {

	
	public void calcula(Partida partida) {
		// tempo dificuldade qntde de erros
		
		DificuldadePartida facil = DificuldadePartida.FACIL;
		DificuldadePartida normal = DificuldadePartida.NORMAL;
		DificuldadePartida dificil = DificuldadePartida.DIFICIL;
		
		Date tempoDecorrido = new Date();
		
		if(partida.getDificuldade() == facil ){
			partida.setScore(partida.getScore()  - partida.getQntdeErros() - tempoDecorrido.getMinutes()); 
			System.out.println(partida.getScore());
		}
		if(partida.getDificuldade() == normal){
			partida.setScore(partida.getScore() - partida.getQntdeErros()*2 - tempoDecorrido.getMinutes());
			System.out.println(partida.getScore());
		}
		if(partida.getDificuldade() == dificil){
			partida.setScore(partida.getScore() - partida.getQntdeErros()*3 - tempoDecorrido.getMinutes());
			System.out.println(partida.getScore());
		}
	}

}
