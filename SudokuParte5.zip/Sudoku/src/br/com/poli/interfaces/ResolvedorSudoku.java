package br.com.poli.interfaces;
import br.com.poli.Tabuleiro;
import br.com.poli.exceptions.TabuleiroSemSolucaoException;
import br.com.poli.DificuldadePartida;

public interface ResolvedorSudoku {
	void resolvedor(int lin, int col) throws TabuleiroSemSolucaoException;
}
