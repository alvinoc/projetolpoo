package br.com.poli.interfaces;

import br.com.poli.Partida;

public interface CalculaScore {
	void calcula(Partida partida); // todo metodo numa interface � publico e abstrato
	
}
