package br.com.poli.testes;
import br.com.poli.Jogador;

public class TesteJogador {

	public static void main(String[] args) {
		Jogador jogador = new Jogador(12,"pedro", 32 );
		

	}

}
