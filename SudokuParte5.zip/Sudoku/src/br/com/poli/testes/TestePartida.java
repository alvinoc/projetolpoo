package br.com.poli.testes;
import br.com.poli.Partida;
import br.com.poli.DificuldadePartida;
import br.com.poli.Jogador;
import br.com.poli.Tabuleiro;
import br.com.poli.exceptions.MovimentoIncorretoException;
import br.com.poli.exceptions.MovimentoInvalidoException;
import br.com.poli.exceptions.TabuleiroSemSolucaoException;

import java.util.Date;

public class TestePartida {
	


	public static void main(String[] args) throws MovimentoInvalidoException, MovimentoIncorretoException, TabuleiroSemSolucaoException {
		Jogador jogador = new Jogador(12,"asdads", 123);
		int[][] gabarito = {
				{8,3,2,4,7,5,6,9,1},
				{9,5,6,3,8,1,4,7,2},
				{7,4,1,6,2,9,8,3,5},
				{6,9,8,7,5,3,2,1,4},
				{3,7,5,2,1,4,9,8,6},
				{1,2,4,9,6,8,3,5,7},
				{4,1,3,5,9,2,7,6,8},
				{5,6,9,8,4,7,1,2,3},
				{2,8,7,1,3,6,5,4,9},};
		int[][]	grid = {
				{8,3,0,0,0,5,6,9,0},
				{0,0,6,0,8,0,0,0,2},
				{0,0,0,6,0,0,0,0,5},
				{6,0,0,0,0,3,0,0,0},
				{3,0,5,0,0,0,9,0,6},
				{0,0,0,9,0,0,0,0,7},
				{4,0,0,0,0,2,0,0,0},
				{5,0,0,0,4,0,1,0,0},
				{0,8,7,1,0,0,0,4,9}};
		Date data = new Date();
		Tabuleiro tabuleiro = new Tabuleiro(gabarito, grid);
		Partida partida = new Partida(jogador, tabuleiro, 1, false, 0, data);
		DificuldadePartida facil =   DificuldadePartida.FACIL;

		partida.resolvedor(0, 0);
		
		//partida.isFimDeJogo();

	}


}
