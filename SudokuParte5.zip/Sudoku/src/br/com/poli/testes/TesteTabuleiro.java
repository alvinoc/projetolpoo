package br.com.poli.testes;
import br.com.poli.Tabuleiro ;
import br.com.poli.exceptions.MovimentoIncorretoException;
import br.com.poli.exceptions.MovimentoInvalidoException;
import br.com.poli.exceptions.TabuleiroSemSolucaoException;
import br.com.poli.DificuldadePartida;


public class TesteTabuleiro {
	//Metodo criado para converter o array bidimensional em uma string para que seja printada na tela do console 
	public static String arrayToString(int[][] grid) {

	    String aString;     
	    aString = "";
	    int coluna;
	    int linha;

	    for (linha = 0; linha < grid.length; linha++) {
	        for (coluna = 0; coluna < grid[0].length; coluna++ ) {
	        aString = aString + " " + grid[linha][coluna];
	        }
	    aString = aString + "\n";
	    }
	    System.out.println(aString);
	    return aString;
	}

	public static void main(String[] args) throws MovimentoInvalidoException, MovimentoIncorretoException, TabuleiroSemSolucaoException {
		DificuldadePartida facil = DificuldadePartida.FACIL;
		DificuldadePartida normal = DificuldadePartida.NORMAL;
		DificuldadePartida dificil = DificuldadePartida.DIFICIL;
		int[][] gabarito = {
				{8,3,2,4,7,5,6,9,1},
				{9,5,6,3,8,1,4,7,2},
				{7,4,1,6,2,9,8,3,5},
				{6,9,8,7,5,3,2,1,4},
				{3,7,5,2,1,4,9,8,6},
				{1,2,4,9,6,8,3,5,7},
				{4,1,3,5,9,2,7,6,8},
				{5,6,9,8,4,7,1,2,3},
				{2,8,7,1,3,6,5,4,9},};
		int[][]	grid = {
				{8,3,0,0,0,5,6,9,0},
                {0,0,6,0,8,0,0,0,2},
                {0,0,0,6,0,0,0,0,5},
                {6,0,0,0,0,3,0,0,0},
                {3,0,5,0,0,0,9,0,6},
                {0,0,0,9,0,0,0,0,7},
                {4,0,0,0,0,2,0,0,0},
                {5,0,0,0,4,0,1,0,0},
                {0,8,7,1,0,0,0,4,9}};
		Tabuleiro tabuleiro = new Tabuleiro(gabarito, grid);
		
		
			tabuleiro.executarMovimento(0, 2, 2);
				
				
			
	
		
		

	}

}
