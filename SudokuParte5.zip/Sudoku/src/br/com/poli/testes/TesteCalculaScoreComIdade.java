package br.com.poli.testes;
import br.com.poli.CalculaScoreComIdade;
import br.com.poli.Partida;
import br.com.poli.Jogador;
import br.com.poli.Tabuleiro;
import br.com.poli.interfaces.CalculaScore;
import br.com.poli.DificuldadePartida;
import java.util.Date;


public class TesteCalculaScoreComIdade {

	public static void main(String[] args) {
		
		DificuldadePartida facil = DificuldadePartida.FACIL;
		DificuldadePartida normal = DificuldadePartida.NORMAL;
		DificuldadePartida dificil = DificuldadePartida.DIFICIL;
		
		Date tempo = new Date();

		int[][] grid = new int[10][10];

		int[][] gabarito = new int[10][10];

		Jogador pedro = new Jogador(12, "pedro", 23);

		Tabuleiro tabuleiro = new Tabuleiro(gabarito, grid);

		Partida partida = new Partida(pedro, tabuleiro, 2, true, 23, tempo);
		
		CalculaScore calcula = new CalculaScoreComIdade();
		calcula.calcula(partida);
		

		

	}

}
