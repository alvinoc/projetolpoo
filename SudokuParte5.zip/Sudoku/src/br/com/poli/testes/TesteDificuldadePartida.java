package br.com.poli.testes;
import br.com.poli.DificuldadePartida;
public class TesteDificuldadePartida {

	public static void main(String[] args) {
		DificuldadePartida facil = DificuldadePartida.FACIL;
		DificuldadePartida normal = DificuldadePartida.NORMAL;
		DificuldadePartida dificil = DificuldadePartida.DIFICIL;
		System.out.println(facil.getQntdeMaxErros());
		System.out.println(DificuldadePartida.DIFICIL.getValor());	
		System.out.println(DificuldadePartida.NORMAL.getQntdeMaxErros());
		

	}

}
