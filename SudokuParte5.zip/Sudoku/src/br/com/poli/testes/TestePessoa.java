package br.com.poli.testes;
import br.com.poli.Pessoa;
public class TestePessoa {

	public static void main(String[] args) {
		

	}

}
